# Community Supported

This template/script/solution is released “as-is”, with no warranty and no support. These should be seen as community
supported and Palo Alto Networks may contribute its expertise at its discretion. Palo Alto Networks, including through
its Authorized Support Centers (ASC) partners and backline support options, will not provide technical support or help
in using or troubleshooting this template/script/solution. The underlying product used by this template/script/solution
will still be supported in accordance with the product’s applicable support policy and the customer’s entitlements.